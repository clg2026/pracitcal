console.log("Name: vipin")
console.log("class: TE")
console.log("Subject: wad lp-2")
console.log("description: Assignment 2b")